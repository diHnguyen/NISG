global arcs = [1 2; 1 3; 1 4; 1 5; 2 5; 2 6; 3 6; 4 6; 5 6]
global d = [2, 10, 4, 1, 7, 6, 0, 3, 8]
global q = [0.9, 0.7, 0.1, 0.3, 0.9, 0.7, 0.4, 0.3, 0.7]
global b = 5
global origin = 1
global destination = 6
#Density = 0.4
