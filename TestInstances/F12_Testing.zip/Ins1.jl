global arcs = [1 4; 1 5; 1 6; 2 6; 3 6; 1 2; 1 3; 4 6; 5 6]
global d = [2, 5, 2, 7, 1, 0, 0, 5, 5]
global q = [0.8, 0.4, 0.6, 0.9, 0.4, 0.6, 0.1, 0.4, 0.9]
global b = 5
global origin = 1
global destination = 6
#Density = 0.4
