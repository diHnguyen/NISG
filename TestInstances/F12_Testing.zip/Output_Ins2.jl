Obj = 0.5
x = [7, 10]
y = [9] ; [1.0]
#Verify
Set of maximally packed x-solution = Any[[2, 7, 10], [7, 8, 10]]
x = [2, 7, 10] ; v** = 0.5 ; minCut = [9] ; [1.0]
x = [7, 8, 10] ; v** = 0.5 ; minCut = [9] ; [1.0]
