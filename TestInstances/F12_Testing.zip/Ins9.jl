global arcs = [1 3; 1 4; 1 5; 1 6; 2 4; 2 6; 3 4; 1 2; 4 6; 5 6]
global d = [5, 1, 3, 1, 8, 10, 4, 10, 3, 4]
global q = [0.0, 0.8, 0.2, 0.7, 0.1, 0.1, 0.1, 0.7, 1.0, 0.4]
global b = 5
global origin = 1
global destination = 6
#Density = 0.4
