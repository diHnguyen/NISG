Obj = -0.0
x = Int64[]
y = [1] ; [1.0]
#Verify
Set of maximally packed x-solution = Any[[7, 8], [1, 6, 7], [3, 5, 7], [4, 5, 7], [1, 3, 4, 7], [3, 4, 6, 7]]
x = [7, 8] ; The evader always reaches the target destination.
x = [1, 6, 7] ; The evader always reaches the target destination.
x = [3, 5, 7] ; The evader always reaches the target destination.
x = [4, 5, 7] ; The evader always reaches the target destination.
x = [1, 3, 4, 7] ; The evader always reaches the target destination.
x = [3, 4, 6, 7] ; The evader always reaches the target destination.
