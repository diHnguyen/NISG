Obj = 1.3000000000465661
x = [2, 3, 5, 7]
y = [4] ; [1.0]
#Verify
Set of maximally packed x-solution = Any[[4, 5, 7], [2, 3, 5, 7]]
x = [4, 5, 7] ; No monitoring is required.
x = [2, 3, 5, 7] ; No monitoring is required.
