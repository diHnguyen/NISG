global arcs = [1 2; 1 5; 2 4; 3 4; 4 6; 1 3; 5 6]
global d = [8, 2, 3, 5, 0, 10, 0]
global q = [0.4, 0.3, 0.2, 0.3, 0.0, 0.0, 0.9]
global b = 5
global origin = 1
global destination = 6
#Density = 0.4
