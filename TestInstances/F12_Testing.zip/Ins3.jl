global arcs = [1 3; 1 6; 2 6; 3 4; 5 6; 1 2; 1 5; 4 6]
global d = [3, 9, 1, 1, 4, 2, 0, 5]
global q = [0.1, 0.0, 0.2, 0.0, 0.9, 0.3, 0.1, 0.4]
global b = 5
global origin = 1
global destination = 6
#Density = 0.4
