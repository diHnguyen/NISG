global arcs = [1 3; 1 4; 1 6; 2 4; 2 5; 2 6; 3 4; 3 5; 1 2; 4 6; 5 6]
global d = [1, 1, 10, 9, 8, 6, 6, 1, 2, 5, 6]
global q = [0.5, 1.0, 0.1, 1.0, 0.2, 0.6, 0.1, 0.1, 0.0, 0.1, 0.6]
global b = 5
global origin = 1
global destination = 6
#Density = 0.4
