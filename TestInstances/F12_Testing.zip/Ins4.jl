global arcs = [1 3; 1 5; 1 6; 2 3; 3 5; 3 6; 4 5; 5 6; 1 2; 1 4]
global d = [6, 9, 5, 9, 7, 2, 8, 10, 7, 3]
global q = [0.6, 0.6, 0.1, 0.4, 0.8, 0.2, 0.2, 0.9, 0.9, 0.7]
global b = 5
global origin = 1
global destination = 6
#Density = 0.4
